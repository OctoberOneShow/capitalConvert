(function(){
  function getFileName(path){
    try { return path.split('/').pop().split('\\').pop(); } catch { return path; }
  }

  function setActiveNav(){
    var current = getFileName(location.pathname || 'index.html');
    document.querySelectorAll('nav a').forEach(function(a){
      var hrefFile = getFileName(a.getAttribute('href') || '');
      if (!hrefFile) return;
      if (current === '' && hrefFile === 'index.html') {
        a.classList.add('active');
        return;
      }
      if (current === hrefFile) a.classList.add('active');
    });
  }

  function initTheme(){
    var preferred = localStorage.getItem('theme');
    var systemDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = preferred || (systemDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    var toggle = document.getElementById('themeToggle');
    if (toggle){
      toggle.textContent = theme === 'dark' ? '☀️' : '🌙';
      toggle.addEventListener('click', function(){
        var current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        var next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        toggle.textContent = next === 'dark' ? '☀️' : '🌙';
      });
    }
  }

  function initCopy(){
    var btn = document.getElementById('copyBtn');
    var output = document.getElementById('outputText');
    if (!btn || !output) return;
    btn.addEventListener('click', function(){
      try {
        output.select();
        document.execCommand('copy');
      } catch(e) {
        navigator.clipboard && navigator.clipboard.writeText(output.value);
      }
      var original = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(function(){ btn.textContent = original; }, 1200);
    });
  }

  function initShortcuts(){
    var input = document.getElementById('inputText');
    var output = document.getElementById('outputText');
    var primary = document.getElementById('primaryBtn');

    if (input){
      input.addEventListener('keydown', function(e){
        if (e.ctrlKey && (e.key === 'Enter' || e.keyCode === 13)){
          if (primary) primary.click();
        }
      });
    }

    if (output){
      output.addEventListener('keydown', function(e){
        if (e.ctrlKey && (e.key === 'a' || e.keyCode === 65)){
          e.preventDefault();
          output.select();
        }
        if (e.ctrlKey && (e.key === 'x' || e.keyCode === 88)){
          var selected = output.value.substring(output.selectionStart, output.selectionEnd);
          navigator.clipboard && navigator.clipboard.writeText(selected);
          var next = output.value.substring(0, output.selectionStart) + output.value.substring(output.selectionEnd);
          output.value = next;
          e.preventDefault();
        }
      });
    }
  }

  function triggerConvertFX(){
    var output = document.getElementById('outputText');
    var section = output && output.closest && output.closest('.section');
    var btn = document.getElementById('primaryBtn');

    if (section){
      section.classList.remove('flash-success');
      void section.offsetWidth; // restart animation
      section.classList.add('flash-success');
      setTimeout(function(){ section.classList.remove('flash-success'); }, 950);
    }
    if (output){
      output.classList.remove('flash-success');
      void output.offsetWidth;
      output.classList.add('flash-success');
      setTimeout(function(){ output.classList.remove('flash-success'); }, 850);
    }
    if (btn){
      btn.classList.remove('flash');
      void btn.offsetWidth;
      btn.classList.add('flash');
      setTimeout(function(){ btn.classList.remove('flash'); }, 320);
    }
  }

  document.addEventListener('DOMContentLoaded', function(){
    setActiveNav();
    initTheme();
    initCopy();
    initShortcuts();

    // Trigger page-load reveal animations
    requestAnimationFrame(function(){
      document.body.classList.add('is-loaded');
    });
  });

  // --- Page functions ---
  window.formatText = function(){
    var inputText = document.getElementById('inputText').value;
    var isAllCaps = inputText === inputText.toUpperCase();
    var lines = inputText.split('\n');

    var formattedLines = lines.map(function(line){
      if (line.trim() === '') return line;

      var formattedLine = isAllCaps ? line.toLowerCase() : line;

      // Handle multiple capitalized words
      var hasMultipleCapitalizedWords = formattedLine.split(' ')
        .filter(function(word){ return word.length >= 2; })
        .filter(function(word){ return word === word.toUpperCase() && /^[A-Z][A-Z'\u2018\u2019\-]*$/.test(word); })
        .length >= 2;

      if (hasMultipleCapitalizedWords || /\b[A-Z][A-Z'\u2018\u2019\-]+\b/.test(formattedLine)){
        var words = formattedLine.split(' ');
        var processedWords = words.map(function(word){
          if (word.length >= 2 && word === word.toUpperCase() && /^[A-Z][A-Z'\u2018\u2019\-]*$/.test(word)){
            return word.toLowerCase();
          }
          return word;
        });
        formattedLine = processedWords.join(' ');
      }

      // Capitalize first letter
      formattedLine = formattedLine.charAt(0).toUpperCase() + formattedLine.slice(1);

      // Fix common contractions and words
      formattedLine = formattedLine.replace(/\bi\b/g, 'I');
      formattedLine = formattedLine.replace(/\bIve\b/g, "I've");
      formattedLine = formattedLine.replace(/\bIam\b/g, 'I am');
      formattedLine = formattedLine.replace(/\bIm\b/g, "I'm");
      formattedLine = formattedLine.replace(/\bImma\b/g, "I'mma");
      formattedLine = formattedLine.replace(/\bI dont\b/g, "I don't");
      formattedLine = formattedLine.replace(/\bIll\b/g, "I'll");
      formattedLine = formattedLine.replace(/\bId\b/g, "I'd");
      formattedLine = formattedLine.replace(/\byoure\b/gi, "you're");
      formattedLine = formattedLine.replace(/\byoull\b/gi, "you'll");
      formattedLine = formattedLine.replace(/\byoud\b/gi, "you'd");
      formattedLine = formattedLine.replace(/\bwont\b/gi, "won't");
      formattedLine = formattedLine.replace(/\bcant\b/gi, "can't");
      formattedLine = formattedLine.replace(/\bdont\b/gi, "don't");
      formattedLine = formattedLine.replace(/\bdidnt\b/gi, "didn't");
      formattedLine = formattedLine.replace(/\bwasnt\b/gi, "wasn't");
      formattedLine = formattedLine.replace(/\bwerent\b/gi, "weren't");
      formattedLine = formattedLine.replace(/\bisnt\b/gi, "isn't");
      formattedLine = formattedLine.replace(/\barent\b/gi, "aren't");
      formattedLine = formattedLine.replace(/\bhavent\b/gi, "haven't");
      formattedLine = formattedLine.replace(/\bhasnt\b/gi, "hasn't");
      formattedLine = formattedLine.replace(/\bhadnt\b/gi, "hadn't");
      formattedLine = formattedLine.replace(/\bweve\b/gi, "we've");
      formattedLine = formattedLine.replace(/\btheyll\b/gi, "they'll");
      formattedLine = formattedLine.replace(/\btheyre\b/gi, "they're");
      formattedLine = formattedLine.replace(/\btheyve\b/gi, "they've");
      formattedLine = formattedLine.replace(/\btheyd\b/gi, "they'd");
      formattedLine = formattedLine.replace(/\bwere\b/gi, "we're");
      formattedLine = formattedLine.replace(/\bwell\b/gi, "we'll");
      formattedLine = formattedLine.replace(/\bwed\b/gi, "we'd");
      formattedLine = formattedLine.replace(/\bshes\b/gi, "she's");
      formattedLine = formattedLine.replace(/\bhes\b/gi, "he's");
      formattedLine = formattedLine.replace(/\bits\b/gi, "it's");
      formattedLine = formattedLine.replace(/\bthats\b/gi, "that's");
      formattedLine = formattedLine.replace(/\bwhats\b/gi, "what's");
      formattedLine = formattedLine.replace(/\bwheres\b/gi, "where's");
      formattedLine = formattedLine.replace(/\btheres\b/gi, "there's");
      formattedLine = formattedLine.replace(/\bheres\b/gi, "here's");

      // Handle 'cause variations
      formattedLine = formattedLine.replace(/(?<!')\b(cause)\b/gi, "'cause");
      formattedLine = formattedLine.replace(/(?:^|\.\s+)('?)(c)(ause)\b/gi, function(match, apostrophe, cLetter){
        return (apostrophe ? "'" : "'") + cLetter.toUpperCase() + "ause".toLowerCase();
      });

      // Ensure first letter is capitalized
      formattedLine = formattedLine.charAt(0).toUpperCase() + formattedLine.slice(1);

      // Remove square brackets and their contents
      formattedLine = formattedLine.replace(/\[.*?\]/g, '');

      // Filter characters while preserving English letters, numbers, punctuation, and Chinese characters
      var preservedFormatting = formattedLine.split('').map(function(char){
        if (/[a-zA-Z0-9\s\.,!?`'"\-:;()\[\]{}]|[\u2018\u2019\u0027]|[一-鿿]/.test(char)) {
          return char;
        }
        return '';
      }).join('');

      return preservedFormatting;
    });

    var formattedText = formattedLines.join('\n');

    document.getElementById('outputText').value = formattedText;
    document.getElementById('inputText').value = '';
    var outputTextarea = document.getElementById('outputText');
    outputTextarea.focus();
    outputTextarea.select();
    triggerConvertFX();
  };

  window.filterText = function(){
    var inputText = document.getElementById('inputText').value;
    var lines = inputText.split('\n');

    var filteredLines = lines.map(function(line){
      return line.split('').map(function(char){
        if (/[a-zA-Z0-9\s\.,!?`'"\-:;()\[\]{}@#$%^&*+=|\\/<>~_]/.test(char)) {
          return char;
        }
        if (/[\u4e00-\u9fff\u3400-\u4dbf\u20000-\u2a6df\u2a700-\u2b73f\u2b740-\u2b81f\u2b820-\u2ceaf]/.test(char)) {
          return '';
        }
        return char;
      }).join('');
    });

    var filteredText = filteredLines.join('\n');

    document.getElementById('outputText').value = filteredText;
    document.getElementById('inputText').value = '';
    var outputTextarea = document.getElementById('outputText');
    outputTextarea.focus();
    outputTextarea.select();
    triggerConvertFX();
  };

  window.convertPunctuation = function(){
    var input = document.getElementById('inputText');
    var output = document.getElementById('outputText');
    var text = input.value;

    // Convert Chinese punctuation to English equivalents / remove unwanted
    text = text.replace(/，/g, ' ');
    text = text.replace(/。/g, '');
    text = text.replace(/！/g, '');
    text = text.replace(/？/g, '');
    text = text.replace(/-/g, '');

    // Ellipsis normalization: convert ellipsis variants to a single space
    text = text.replace(/[…⋯]+/g, ' ');   // U+2026, U+22EF and repeats -> space
    text = text.replace(/\.{3,}/g, ' ');  // 3 or more dots -> space
    text = text.replace(/ {2,}/g, ' ');    // collapse duplicate spaces (preserve newlines)

    output.value = text;
    input.value = '';
    output.focus();
    output.select();
    triggerConvertFX();
  };
})(); 